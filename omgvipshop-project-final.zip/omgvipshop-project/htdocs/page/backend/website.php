<div class="p-4 p-lg-5">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-browser text-xdvz-primary me-2"></i> จัดการเว็บไซต์
            </h3>
            <p class="text-muted small mb-0">ปรับแต่งข้อมูลพื้นฐาน สี และธีมของเว็บไซต์คุณ</p>
        </div>
        <button class="btn xdvz-btn-cyan shadow-sm px-4" id="open_insert">
            <i class="fa-solid fa-chart-line me-2"></i> สถิติโชว์
        </button>
    </div>

    <div class="row g-4">
        <!-- Main Form -->
        <div class="col-lg-8">
            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ชื่อเว็บไซต์</label>
                <input type="text" id="site_name" class="form-control py-3" value="<?php echo $config['name']; ?>"
                    style="border-radius: 12px;">
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">ภาพ Logo (URL)</label>
                <input type="text" id="site_logo" class="form-control py-3" value="<?php echo $config['logo']; ?>"
                    style="border-radius: 12px;">
            </div>

            <?php
            $theme_main_color = strtolower(trim($config['main_color'] ?? '#8d3cff'));
            $theme_secondary_color = strtolower(trim($config['sec_color'] ?? '#a855f7'));
            $theme_border_color = strtolower(trim($config['border_color'] ?? '#8543be'));
            $is_dark_theme = (($config['theme_mode'] ?? 'light') === 'dark');
            $default_bg_color = '#080510';
            $default_card_color = '#140a22';
            $default_text_color = '#f5efff';
            $theme_text_color = strtolower(trim($config['text_color'] ?? $default_text_color));
            $theme_bg_color = strtolower(trim($config['bg_color'] ?? $default_bg_color));
            $theme_card_color = strtolower(trim($config['card_color'] ?? $default_card_color));
            $theme_button_color = strtolower(trim($config['button_color'] ?? '#8d3cff'));
            $theme_success_color = strtolower(trim($config['success_color'] ?? '#a855f7'));
            $theme_warning_color = strtolower(trim($config['warning_color'] ?? '#8d3cff'));
            $theme_danger_color = strtolower(trim($config['danger_color'] ?? '#ef476f'));
            $theme_info_color = strtolower(trim($config['info_color'] ?? '#a855f7'));
            if (in_array([$theme_main_color, $theme_secondary_color], [
                ['#ff0000', '#ff0000'],
                ['#2563eb', '#06b6d4'],
                ['#00d4ff', '#ff0080'],
                ['#facc15', '#16a34a'],
            ], true)) {
                $theme_main_color = '#8d3cff';
                $theme_secondary_color = '#a855f7';
            }
            if (in_array($theme_text_color, ['#ff0000', '#e2e8f0'], true)) {
                $theme_text_color = '#f5efff';
            }
            ?>
            <div id="theme-settings" class="row g-3 mb-3" style="scroll-margin-top: 90px;">
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีหลัก (Primary)</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_main_color"
                        value="<?php echo htmlspecialchars($theme_main_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีรอง (Secondary)</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_sec_color"
                        value="<?php echo htmlspecialchars($theme_secondary_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีเส้น/เส้นขอบ</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_border_color"
                        value="<?php echo htmlspecialchars($theme_border_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีตัวอักษร</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_text_color"
                        value="<?php echo htmlspecialchars($theme_text_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
            </div>
            <div class="alert alert-info border-0 shadow-sm mb-4" style="background: rgba(141,60,255,.12); color: var(--xez-text-color); border: 1px solid var(--xez-border) !important;">
                <div class="fw-bold mb-1"><i class="fa-solid fa-palette me-2"></i>ธีมนี้มีผลกับทุกจุดของเว็บไซต์</div>
                <div class="small">จุดที่เปลี่ยน: Navbar/เมนู, พื้นหลัง, Hero หน้า Home, การ์ดสินค้าและหมวดหมู่, ปุ่ม, ฟอร์มและช่องกรอกข้อมูล, ตาราง, Badge/ป้ายสถานะ, Modal/Dropdown, กล่องแจ้งเตือน, Footer, ไอคอนเมนู และเอฟเฟกต์เส้นขอบ</div>
            </div>
            <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
                <button type="button" class="btn btn-outline-primary rounded-pill px-3" id="btn_logo_palette">
                    <i class="fa-solid fa-wand-magic-sparkles me-1"></i> ใช้พาเลตสี OMGVIPSHOP
                </button>
                <button type="button" class="btn btn-outline-secondary rounded-pill px-3" id="btn_reset_palette">
                    <i class="fa-solid fa-rotate-left me-1"></i> คืนค่าสีเดิม
                </button>
                <small class="text-muted">สีเดิม: แดง #FF0000 · พื้นหลังขาว #FFFFFF</small>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีพื้นหลัง</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_bg_color"
                        value="<?php echo htmlspecialchars($theme_bg_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีการ์ด</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_card_color"
                        value="<?php echo htmlspecialchars($theme_card_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีปุ่ม</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_button_color"
                        value="<?php echo htmlspecialchars($theme_button_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีสำเร็จ</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_success_color"
                        value="<?php echo htmlspecialchars($theme_success_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีคำเตือน</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_warning_color"
                        value="<?php echo htmlspecialchars($theme_warning_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีข้อผิดพลาด</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_danger_color"
                        value="<?php echo htmlspecialchars($theme_danger_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
                <div class="col-md-3">
                    <label class="form-label text-dark fw-bold small text-center d-block">สีข้อมูล</label>
                    <input type="color" class="form-control form-control-color w-100 py-1" id="site_info_color"
                        value="<?php echo htmlspecialchars($theme_info_color, ENT_QUOTES, 'UTF-8'); ?>" style="height: 60px; border-radius: 12px;">
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-8">
                    <label class="form-label text-dark fw-bold small">ฟอนต์เว็บไซต์</label>
                    <select id="site_font_family" class="form-select py-3" style="border-radius: 12px;">
                        <?php $font_family = $config['font_family'] ?? 'kanit'; ?>
                        <option value="kanit" <?= $font_family === 'kanit' ? 'selected' : '' ?>>Kanit (แนะนำ)</option>
                        <option value="prompt" <?= $font_family === 'prompt' ? 'selected' : '' ?>>Prompt</option>
                        <option value="sarabun" <?= $font_family === 'sarabun' ? 'selected' : '' ?>>Sarabun</option>
                        <option value="ibm_plex_sans_thai" <?= $font_family === 'ibm_plex_sans_thai' ? 'selected' : '' ?>>IBM Plex Sans Thai</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label text-dark fw-bold small">ขนาดตัวอักษรพื้นฐาน</label>
                    <select id="site_font_size" class="form-select py-3" style="border-radius: 12px;">
                        <?php $font_size = (int) ($config['font_size'] ?? 16); ?>
                        <?php foreach ([14, 15, 16, 17, 18, 20] as $size): ?>
                            <option value="<?= $size ?>" <?= $font_size === $size ? 'selected' : '' ?>><?= $size ?> px</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">โหมดการแสดงผล (Theme)</label>
                <div class="row g-3">
                    <div class="col-6">
                        <input type="radio" class="btn-check" name="theme_mode" id="theme_light" value="light" <?php if (($config['theme_mode'] ?? 'light') == 'light')
                            echo 'checked'; ?>>
                        <label class="btn btn-outline-warning w-100 py-3 fw-bold shadow-none" for="theme_light"
                            style="border-radius: 15px;">
                            <i class="fa-solid fa-sun me-2"></i> Light Mode
                        </label>
                    </div>
                    <div class="col-6">
                        <input type="radio" class="btn-check" name="theme_mode" id="theme_dark" value="dark" <?php if (($config['theme_mode'] ?? 'light') == 'dark')
                            echo 'checked'; ?>>
                        <label class="btn btn-outline-dark w-100 py-3 fw-bold shadow-none" for="theme_dark"
                            style="border-radius: 15px;">
                            <i class="fa-solid fa-moon me-2"></i> Dark Mode
                        </label>
                    </div>
                </div>
            </div>

                        <div class="mb-4">
                <label class="form-label text-dark fw-bold small">Webhook Discord</label>
                <input type="text" id="webhook_dc" class="form-control py-3"
                    value="<?php echo $config['webhook_dc']; ?>" style="border-radius: 12px;">
            </div>

            <div class="mb-4 p-3 bg-light rounded-4 border">
                <label class="form-label text-dark fw-bold small mb-3">
                    <i class="fa-brands fa-discord text-primary me-1"></i> แจ้งเตือนรายการผ่าน Discord
                </label>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="discord_topup_notify">แจ้งเตือนเมื่อเติมเงิน</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="discord_topup_notify"
                                <?php if (($config['discord_topup_notify'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="discord_purchase_notify">แจ้งเตือนเมื่อซื้อสินค้า</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="discord_purchase_notify"
                                <?php if (($config['discord_purchase_notify'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                </div>
                <small class="text-muted d-block mt-3">ต้องตั้งค่า Webhook Discord ด้านบนก่อน ระบบจะส่งแจ้งเตือนหลังรายการสำเร็จเท่านั้น</small>
            </div>

            <div class="mb-4">

                <label class="form-label text-dark fw-bold small">Discord Server ID (สำหรับ Widget ใน Footer)</label>
                <div class="input-group mb-2">
                    <input type="text" id="discord_server" class="form-control py-3"
                        value="<?php echo $config['discord_server'] ?? ''; ?>" style="border-radius: 12px 0 0 12px;"
                        placeholder="เช่น 123456789012345678">
                    <div class="input-group-text bg-white border-start-0" style="border-radius: 0 12px 12px 0;">
                        <div class="form-check form-switch m-0">
                            <input class="form-check-input" type="checkbox" role="switch" id="discord_widget_status" 
                                <?php if (($config['discord_widget_status'] ?? 'off') === 'on') echo 'checked'; ?>>
                            <label class="form-check-label small fw-bold ms-1" for="discord_widget_status">เปิด Widget</label>
                        </div>
                    </div>
                </div>
                <small class="text-muted">หา Server ID: คลิกขวาที่เซิร์ฟเวอร์ > Copy Server ID (ต้องเปิด Widget ใน Discord Server ด้วย)</small>
            </div>

            <div class="mb-4 p-3 bg-light rounded-4 border">
                <label class="form-label text-dark fw-bold small mb-3">การตั้งค่าช่องทางการติดต่อ (Social Media)</label>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-facebook text-primary me-1"></i> Facebook Page</label>
                        <input type="text" id="contact_facebook" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_facebook'] ?? '#'); ?>" placeholder="URL ของ Facebook Page">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-line text-success me-1"></i> Line Official</label>
                        <input type="text" id="contact_line" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_line'] ?? '#'); ?>" placeholder="URL หรือ ID ของ Line">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-discord text-info me-1"></i> Discord Invite</label>
                        <input type="text" id="contact_discord" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_discord'] ?? '#'); ?>" placeholder="URL คำเชิญ Discord">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-facebook-messenger text-primary me-1"></i> Messenger</label>
                        <input type="text" id="contact_messenger" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_messenger'] ?? '#'); ?>" placeholder="URL ของ Messenger (m.me)">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-telegram text-info me-1"></i> Telegram 1</label>
                        <input type="text" id="contact_telegram1" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_telegram1'] ?? '#'); ?>" placeholder="URL หรือ Username Telegram 1">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold"><i class="fa-brands fa-telegram text-info me-1"></i> Telegram 2</label>
                        <input type="text" id="contact_telegram2" class="form-control py-2" value="<?php echo htmlspecialchars($config['contact_telegram2'] ?? '#'); ?>" placeholder="URL หรือ Username Telegram 2">
                    </div>
                </div>
                <small class="text-muted d-block mt-2">ใส่ # หากไม่ต้องการใช้งานช่องทางนั้นๆ</small>
            </div>

            <div class="mb-4 p-3 bg-light rounded-4 border chat-toggle-card">
                <div class="form-check form-switch d-flex align-items-center justify-content-between p-0">
                    <div>
                        <label class="form-check-label fw-bold text-dark" for="chat_status">
                            <i class="fa-solid fa-comments text-primary me-1"></i> ระบบแชทกับแอดมิน
                        </label>
                        <p class="text-muted small mb-0">เมื่อปิด ระบบจะซ่อนปุ่มแชทฝั่งผู้ใช้และไม่รับข้อความใหม่</p>
                    </div>
                    <div class="chat-toggle-control ms-3">
                        <span id="chat_status_label" class="chat-status-label" aria-live="polite"></span>
                        <input class="form-check-input" type="checkbox" role="switch" id="chat_status"
                            <?php if (($config['chat_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                    </div>
                </div>
            </div>

            <div id="admin-idle-timeout" class="mb-4 p-3 bg-light rounded-4 border" style="scroll-margin-top: 90px;">
                <label class="form-label text-dark fw-bold small" for="admin_idle_timeout">
                    <i class="fa-solid fa-clock text-warning me-1"></i> เวลาออกจากระบบหลังบ้านอัตโนมัติ
                </label>
                <select id="admin_idle_timeout" class="form-select py-2" style="border-radius: 12px;">
                    <?php $admin_idle_timeout = (int) ($config['admin_idle_timeout'] ?? 30); ?>
                    <?php foreach ([10, 20, 30, 60, 120] as $timeout_minutes): ?>
                        <option value="<?= $timeout_minutes ?>" <?= $admin_idle_timeout === $timeout_minutes ? 'selected' : '' ?>><?= $timeout_minutes ?> นาที</option>
                    <?php endforeach; ?>
                </select>
                <small class="text-muted d-block mt-2">หากไม่มีการขยับเมาส์ กดแป้นพิมพ์ หรือใช้งานหน้าเว็บตามเวลาที่เลือก ระบบจะออกจากระบบอัตโนมัติ</small>
            </div>

            <div id="finance-settings" class="mb-4 p-3 rounded-4 border finance-settings-card" style="scroll-margin-top: 90px;">
                <h5 class="fw-bold text-dark mb-1"><i class="fa-solid fa-wallet text-success me-2"></i>การเงินและช่องทางเติมเงิน</h5>
                <p class="text-muted small mb-3">ตั้งค่าเบอร์รับเงินและเลือกช่องทางเติมเงินที่เปิดให้ลูกค้าใช้งาน</p>
                <div class="mb-4">
                    <label class="form-label text-dark fw-bold small">เบอร์ Wallet (รับเงิน)</label>
                    <input type="text" id="site_phone" class="form-control py-3" value="<?php echo $config['wallet']; ?>"
                        style="border-radius: 12px;">
                </div>

            <div class="mb-4 p-3 bg-light rounded-4 border">
                <label class="form-label text-dark fw-bold small mb-3">เปิด-ปิดระบบเติมเงินแต่ละช่องทาง</label>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="topup_gift_status">TrueMoney Gift</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="topup_gift_status"
                                <?php if (($config['topup_gift_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="topup_redeem_status">Redeem Code</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="topup_redeem_status"
                                <?php if (($config['topup_redeem_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="topup_slip_status">SLIP CHECK</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="topup_slip_status"
                                <?php if (($config['topup_slip_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="topup_promptpay_status">PromptPay QR</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="topup_promptpay_status"
                                <?php if (($config['topup_promptpay_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3">
                            <label class="form-check-label fw-bold" for="topup_card_status"><i class="fa-solid fa-credit-card text-warning me-1"></i>บัตร TrueMoney 14 หลัก</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="topup_card_status"
                                <?php if (($config['topup_card_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                </div>
                <small class="text-muted d-block mt-3">ปิดช่องทางที่ไม่ต้องการให้ลูกค้าเห็นในหน้าเติมเงิน</small>
            </div>
            </div>

            <div class="mb-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <label class="form-label text-dark fw-bold small mb-0">ประกาศ (หน้าร้าน)</label>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="announcement_status"
                            <?php if (($config['announcement_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                        <label class="form-check-label small fw-bold text-muted" for="announcement_status">แสดงประกาศ</label>
                    </div>
                </div>
                <input type="text" id="ann" class="form-control py-3" value="<?php echo $config['ann']; ?>"
                    style="border-radius: 12px;">
            </div>

            <div class="mb-4">
                <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3 bg-light">
                    <div>
                        <label class="form-check-label fw-bold text-dark" for="stats_status">แสดงส่วนสถิติร้านค้า (หน้าแรก)</label>
                        <p class="text-muted small mb-0">เปิด/ปิด กล่องแสดงจำนวนสมาชิก หมวดหมู่ สินค้า และยอดขาย</p>
                    </div>
                    <input class="form-check-input ms-2" type="checkbox" role="switch" id="stats_status"
                        <?php if (($config['stats_status'] ?? 'on') === 'on') echo 'checked'; ?>>
                </div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">คำอธิบายร้านค้า (Footer)</label>
                <textarea id="site_des" rows="5" class="form-control"
                    style="border-radius: 12px;"><?php echo $config['des']; ?></textarea>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">เนื้อหาวิธีการใช้งาน (หน้า วิธีใช้)</label>
                <textarea id="how_to_text" rows="6" class="form-control"
                    style="border-radius: 12px;" placeholder="ระบุขั้นตอนวิธีการใช้งานเว็บไซต์..."><?php echo htmlspecialchars($config['how_to_text'] ?? ''); ?></textarea>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">เนื้อหากฎระเบียบและข้อตกลง (หน้า วิธีใช้)</label>
                <textarea id="rules_text" rows="6" class="form-control"
                    style="border-radius: 12px;" placeholder="ระบุกฎระเบียบและข้อตกลงของร้านค้า..."><?php echo htmlspecialchars($config['rules_text'] ?? ''); ?></textarea>
            </div>

            <div class="mb-4 p-3 bg-light rounded-4 border" id="effect-settings-panel">
                <h6 class="fw-bold mb-1 text-dark"><i class="fa-solid fa-wand-magic-sparkles me-1"></i> ตั้งค่าเอฟเฟกต์เว็บไซต์</h6>
                <p class="text-muted small mb-3">เปิด/ปิดเอฟเฟกต์ฝนและเส้นแสงรอบการ์ด พร้อมเลือกสีได้จากหน้านี้</p>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3 bg-white">
                            <label class="form-check-label fw-bold" for="rain_enabled">เอฟเฟกต์ฝนตก</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="rain_enabled" <?php if (($config['rain_enabled'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check form-switch d-flex align-items-center justify-content-between border rounded-3 p-3 bg-white">
                            <label class="form-check-label fw-bold" for="glow_enabled">เส้นแสงรอบการ์ด</label>
                            <input class="form-check-input ms-2" type="checkbox" role="switch" id="glow_enabled" <?php if (($config['glow_enabled'] ?? 'on') === 'on') echo 'checked'; ?>>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small" for="rain_density">ปริมาณฝน <span id="rain_density_value"><?= (int)($config['rain_density'] ?? 70) ?></span></label>
                        <input type="range" class="form-range" id="rain_density" min="20" max="130" value="<?= (int)($config['rain_density'] ?? 70) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold small" for="glow_speed">ความเร็วเส้นแสง <span id="glow_speed_value"><?= (int)($config['glow_speed'] ?? 5) ?></span></label>
                        <input type="range" class="form-range" id="glow_speed" min="1" max="10" value="<?= (int)($config['glow_speed'] ?? 5) ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="form-label fw-bold small" for="rain_white_color">สีฝนขาว</label>
                        <input type="color" class="form-control form-control-color w-100" id="rain_white_color" value="<?= htmlspecialchars($config['rain_white_color'] ?? '#ffffff', ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="form-label fw-bold small" for="rain_gray_color">สีฝนเทา</label>
                        <input type="color" class="form-control form-control-color w-100" id="rain_gray_color" value="<?= htmlspecialchars($config['rain_gray_color'] ?? '#aeb2b8', ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="form-label fw-bold small" for="glow_dark_color">สีเส้นแสงเข้ม</label>
                        <input type="color" class="form-control form-control-color w-100" id="glow_dark_color" value="<?= htmlspecialchars($config['glow_dark_color'] ?? '#34363a', ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="form-label fw-bold small" for="glow_light_color">สีเส้นแสงอ่อน</label>
                        <input type="color" class="form-control form-control-color w-100" id="glow_light_color" value="<?= htmlspecialchars($config['glow_light_color'] ?? '#ffffff', ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                </div>
            </div>

            <div class="mb-5 p-3 bg-light rounded-4 border d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="fw-bold mb-1 text-dark">ระบบหักค่าธรรมเนียมสลิป</h6>
                    <p class="text-muted small mb-0">หัก 2.3% ไม่เกิน 10 บาทต่อรายการ</p>
                </div>
                <div class="form-check form-switch fs-4">
                    <input class="form-check-input" type="checkbox" role="switch" id="pc" <?php if ($config['fee'] == "on")
                        echo "checked"; ?>>
                </div>
            </div>

            <button class="btn btn-success w-100 py-3 fw-bold shadow-sm" id="btn_regis"
                style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%); border: none; border-radius: 12px;">
                <i class="fa-solid fa-save me-2"></i> บันทึกข้อมูลเว็บไซต์ทั้งหมด
            </button>
        </div>
    </div>
</div>

<!-- Modal สำหรับตั้งค่าจำนวน -->
<div class="modal fade" id="product_insert" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-header bg-light border-0">
                <h5 class="fw-bold text-dark mb-0">ตั้งค่าสถิติการแสดงผล</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label small fw-bold"><i class="fa-solid fa-users me-1 text-xdvz-primary"></i>
                        เพิ่มจำนวนสมาชิก</label>
                    <input type="number" id="m_count" class="form-control py-2"
                        value="<?php echo $static['m_count'] ?? 0; ?>" placeholder="0">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><i
                            class="fa-solid fa-layer-group me-1 text-xdvz-primary"></i> เพิ่มจำนวนหมวดหมู่</label>
                    <input type="number" id="c_count" class="form-control py-2"
                        value="<?php echo $static['c_count'] ?? 0; ?>" placeholder="0">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold"><i class="fa-solid fa-box-open me-1 text-xdvz-primary"></i>
                        เพิ่มจำนวนสินค้าพร้อมขาย</label>
                    <input type="number" id="s_count" class="form-control py-2"
                        value="<?php echo $static['s_count'] ?? 0; ?>" placeholder="0">
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold"><i class="fa-solid fa-check-circle me-1 text-success"></i>
                        เพิ่มจำนวนขายแล้ว</label>
                    <input type="number" id="sold_count" class="form-control py-2"
                        value="<?php echo $static['sold_count'] ?? 0; ?>" placeholder="0">
                </div>
                <div class="alert alert-info py-2 small mb-0">
                    <i class="fa-solid fa-info-circle me-1"></i> ค่าเหล่านี้จะถูกนำไปบวกรวมกับจำนวนจริงในระบบ
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-success w-100 py-2 rounded-3 fw-bold" id="insert_btn"
                    style="background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%); border: none;">บันทึกสถิติ</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#open_insert").click(() => { new bootstrap.Modal('#product_insert').show(); });

    $("#insert_btn").click(function () {
        var formData = new FormData();
        formData.append('m_count', $("#m_count").val());
        formData.append('c_count', $("#c_count").val());
        formData.append('s_count', $("#s_count").val());
        formData.append('sold_count', $("#sold_count").val());
        $.ajax({
            type: 'POST',
            url: 'system/backend/static_udpate.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({ icon: 'success', title: 'สำเร็จ', text: res.message }).then(() => window.location.reload());
        });
    });

    $("#btn_logo_palette").click(function () {
        $("#site_main_color").val("#8d3cff");
        $("#site_sec_color").val("#a855f7");
        $("#site_border_color").val("#8543be");
        var isDarkTheme = $("#theme_dark").is(":checked");
        $("#site_text_color").val("#f5efff");
        $("#site_bg_color").val("#080510");
        $("#site_card_color").val("#140a22");
        $("#site_button_color").val("#8d3cff");
        $("#site_success_color").val("#a855f7");
        $("#site_warning_color").val("#8d3cff");
        $("#site_danger_color").val("#ef476f");
        $("#site_info_color").val("#a855f7");
        Swal.fire({
            icon: 'success',
            title: 'เลือกพาเลตสีแล้ว',
            text: 'กดปุ่มบันทึกด้านล่างเพื่อใช้งานธีม OMGVIPSHOP บนเว็บไซต์'
        });
    });

    $("#btn_reset_palette").click(function () {
        Swal.fire({
            icon: 'warning',
            title: 'คืนค่าสีเดิม?',
            text: 'ระบบจะเปลี่ยนค่าสีในฟอร์มกลับเป็นสีเดิม แต่ยังไม่บันทึกจนกว่าจะกดปุ่มบันทึก',
            showCancelButton: true,
            confirmButtonText: 'คืนค่าสีเดิม',
            cancelButtonText: 'ยกเลิก',
            confirmButtonColor: '#6c757d'
        }).then(function (result) {
            if (!result.isConfirmed) return;
            $("#site_main_color").val("#8d3cff");
            $("#site_sec_color").val("#a855f7");
            $("#site_border_color").val("#8543be");
            $("#site_text_color").val("#f5efff");
            $("#site_bg_color").val("#080510");
            $("#site_card_color").val("#140a22");
            $("#site_button_color").val("#8d3cff");
            $("#site_success_color").val("#a855f7");
            $("#site_warning_color").val("#a855f7");
            $("#site_danger_color").val("#ef476f");
            $("#site_info_color").val("#a855f7");
            Swal.fire({
                icon: 'success',
                title: 'คืนค่าสีเดิมแล้ว',
                text: 'กดปุ่มบันทึกด้านล่างเพื่อให้เว็บไซต์ใช้สีเดิม'
            });
        });
    });

    function updateToggleStatus(input) {
        var label = input.parentElement.querySelector('.switch-status-label');
        if (!label) {
            label = document.createElement('span');
            label.className = 'switch-status-label';
            label.setAttribute('aria-live', 'polite');
            input.insertAdjacentElement('afterend', label);
        }
        var enabled = input.checked;
        label.textContent = enabled ? 'เปิดอยู่' : 'ปิดอยู่';
        label.classList.toggle('is-on', enabled);
        label.classList.toggle('is-off', !enabled);
        input.setAttribute('aria-label', enabled ? 'เปิดใช้งานอยู่' : 'ปิดใช้งานอยู่');
    }
    document.querySelectorAll('input[type="checkbox"][role="switch"]:not(#chat_status)').forEach(function(input) {
        updateToggleStatus(input);
        input.addEventListener('change', function() { updateToggleStatus(input); });
    });

    function updateChatStatusLabel() {
        var enabled = $('#chat_status').is(':checked');
        var label = $('#chat_status_label');
        label.text(enabled ? 'เปิดอยู่' : 'ปิดอยู่');
        label.toggleClass('is-on', enabled).toggleClass('is-off', !enabled);
        $('#chat_status').attr('aria-label', enabled ? 'ระบบแชทเปิดอยู่' : 'ระบบแชทปิดอยู่');
    }
    updateChatStatusLabel();
    $('#chat_status').on('change', updateChatStatusLabel);
    $('#rain_density').on('input change', function(){ $('#rain_density_value').text(this.value); });
    $('#glow_speed').on('input change', function(){ $('#glow_speed_value').text(this.value); });
    $("#btn_regis").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('name', $("#site_name").val());
        formData.append('bg', 'no'); // Fixed BG for now
        formData.append('phone', $("#site_phone").val());
        formData.append('main_color', $("#site_main_color").val());
        formData.append('logo', $("#site_logo").val());
        formData.append('sec_color', $("#site_sec_color").val());
        formData.append('border_color', $("#site_border_color").val());
        formData.append('text_color', $("#site_text_color").val());
        formData.append('bg_color', $("#site_bg_color").val());
        formData.append('card_color', $("#site_card_color").val());
        formData.append('button_color', $("#site_button_color").val());
        formData.append('success_color', $("#site_success_color").val());
        formData.append('warning_color', $("#site_warning_color").val());
        formData.append('danger_color', $("#site_danger_color").val());
        formData.append('info_color', $("#site_info_color").val());
        formData.append('font_family', $("#site_font_family").val());
        formData.append('font_size', $("#site_font_size").val());
        formData.append('contact_facebook', $("#contact_facebook").val() || '#');
        formData.append('contact_line', $("#contact_line").val() || '#');
        formData.append('contact_discord', $("#contact_discord").val() || '#');
        formData.append('contact_messenger', $("#contact_messenger").val() || '#');
        formData.append('contact_telegram1', $("#contact_telegram1").val() || '#');
        formData.append('contact_telegram2', $("#contact_telegram2").val() || '#');
        formData.append('chat_status', $('#chat_status').is(':checked') ? "on" : "off");
        formData.append('admin_idle_timeout', $('#admin_idle_timeout').val());
        formData.append('contact', $("#contact_facebook").val() || '#'); // Keep for compatibility
        formData.append('theme_mode', $('input[name="theme_mode"]:checked').val());
        formData.append('des', $("#site_des").val());
        formData.append('ann', $("#ann").val());
        formData.append('webhook_dc', $("#webhook_dc").val());
        formData.append('discord_topup_notify', $('#discord_topup_notify').is(':checked') ? "on" : "off");
        formData.append('discord_purchase_notify', $('#discord_purchase_notify').is(':checked') ? "on" : "off");
        formData.append('discord_server', $("#discord_server").val());
        formData.append('discord_widget_status', $('#discord_widget_status').is(':checked') ? "on" : "off");
        formData.append('fee', $('#pc').is(':checked') ? "on" : "off");
        formData.append('topup_gift_status', $('#topup_gift_status').is(':checked') ? "on" : "off");
        formData.append('topup_redeem_status', $('#topup_redeem_status').is(':checked') ? "on" : "off");
        formData.append('topup_slip_status', $('#topup_slip_status').is(':checked') ? "on" : "off");
        formData.append('topup_promptpay_status', $('#topup_promptpay_status').is(':checked') ? "on" : "off");
        formData.append('topup_card_status', $('#topup_card_status').is(':checked') ? "on" : "off");
        formData.append('how_to_text', $("#how_to_text").val());
        formData.append('rules_text', $("#rules_text").val());
        formData.append('announcement_status', $('#announcement_status').is(':checked') ? "on" : "off");
        formData.append('stats_status', $('#stats_status').is(':checked') ? "on" : "off");
        formData.append('rain_enabled', $('#rain_enabled').is(':checked') ? "on" : "off");
        formData.append('rain_density', $('#rain_density').val());
        formData.append('glow_enabled', $('#glow_enabled').is(':checked') ? "on" : "off");
        formData.append('glow_speed', $('#glow_speed').val());
        formData.append('rain_white_color', $('#rain_white_color').val());
        formData.append('rain_gray_color', $('#rain_gray_color').val());
        formData.append('glow_dark_color', $('#glow_dark_color').val());
        formData.append('glow_light_color', $('#glow_light_color').val());

        Swal.fire({ title: 'กำลังบันทึก...', didOpen: () => { Swal.showLoading() } });

        $.ajax({
            type: 'POST',
            url: 'system/backend/website.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({ icon: 'success', title: 'สำเร็จ', text: res.message }).then(() => window.location.reload());
        }).fail(function (jqXHR) {
            Swal.fire({ icon: 'error', title: 'ผิดพลาด', text: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล' });
        });
    });
</script>
<style>
    .chat-toggle-card { border: 2px solid #d9dee7 !important; transition: border-color .2s, box-shadow .2s, background-color .2s; }
    .chat-toggle-card:has(#chat_status:checked) { border-color: #198754 !important; box-shadow: 0 0 0 3px rgba(25, 135, 84, .10); background: #f3fff8 !important; }
    .chat-toggle-card:has(#chat_status:not(:checked)) { border-color: #dc3545 !important; background: #fff7f7 !important; }
    .chat-toggle-control { display: flex; align-items: center; gap: 10px; }
    .chat-status-label { min-width: 70px; padding: 7px 10px; border-radius: 999px; text-align: center; font-weight: 800; font-size: 13px; line-height: 1; }
    .chat-status-label.is-on { color: #0f5132; background: #d1e7dd; border: 1px solid #75b798; }
    .chat-status-label.is-off { color: #842029; background: #f8d7da; border: 1px solid #ea868f; }
    .switch-status-label { display: inline-block; min-width: 62px; margin-left: 8px; padding: 5px 8px; border-radius: 999px; text-align: center; font-weight: 800; font-size: 11px; line-height: 1.1; white-space: nowrap; }
    .switch-status-label.is-on { color: #0f5132; background: #d1e7dd; border: 1px solid #75b798; }
    .switch-status-label.is-off { color: #842029; background: #f8d7da; border: 1px solid #ea868f; }
    #chat_status.form-check-input { width: 3.25em; height: 1.7em; margin-top: 0; cursor: pointer; }
    @media (max-width: 576px) { .chat-toggle-card .form-check { align-items: flex-start !important; gap: 12px; } .chat-toggle-control { flex-shrink: 0; } .switch-status-label { min-width: 56px; padding-left: 5px; padding-right: 5px; } }
</style>
